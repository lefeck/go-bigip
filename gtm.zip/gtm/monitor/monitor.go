package monitor

type MonitorResource struct {
	monitorBigIP            MonitorBigIPResource
	monitorBigIPLink        MonitorBigIPLinkResource
	monitorExternal         MonitorExternalResource
	monitorFTP              MonitorFTPResource
	monitorFirepass         MonitorFirepassResource
	monitorGTP              MonitorGTPResource
	monitorHTTP             MonitorHTTPResource
	monitorHTTPS            MonitorHTTPSResource
	monitorICMP             MonitorICMPResource
	monitorIMAP             MonitorIMAPResource
	monitorLDAP             MonitorLDAPResource
	monitorMSSQL            MonitorMSSQLResource
	monitorMySQL            MonitorMySQLResource
	monitorNNTP             MonitorNNTPResource
	monitorNone             MonitorNoneResource
	monitorOracle           MonitorOracleResource
	monitorPOP3             MonitorPOP3Resource
	monitorPostgreSQL       MonitorPostgreSQLResource
	monitorRadius           MonitorRadiusResource
	monitorRadiusAccounting MonitorRadiusAccountingResource
	monitorRealServer       MonitorRealServerResource
	monitorSIP              MonitorSIPResource
	monitorSMTP             MonitorSMTPResource
	monitorSNMP             MonitorSNMPResource
	monitorSNMPLink         MonitorSNMPLinkResource
	monitorSOAP             MonitorSOAPResource
	monitorTCP              MonitorTCPResource
	monitorTCPHalf          MonitorTCPHalfResource
	monitorUDP              MonitorUDPResource
	monitorWAP              MonitorWAPResource
	monitorWMI              MonitorWMIResource
	monitorscripted         MonitorscriptedResource
}
